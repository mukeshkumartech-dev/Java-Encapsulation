const mysql = require('mysql2');
const bcrypt = require('bcrypt');

// Create MySQL connection pool
const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: 'Mukesh@2006', // Set your MySQL password here
  database: 'voting_system',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

// Function to handle user login
async function authenticateUser(email, password) {
  try {
    const [rows] = await pool.promise().query(
      'SELECT * FROM users WHERE email = ?',
      [email]
    );

    if (rows.length === 0) {
      return { success: false, message: 'User not found' };
    }

    const user = rows[0];
    const match = await bcrypt.compare(password, user.password);

    if (match) {
      return { success: true, user: { id: user.id, email: user.email } };
    } else {
      return { success: false, message: 'Invalid password' };
    }
  } catch (error) {
    console.error('Authentication error:', error);
    return { success: false, message: 'Internal server error' };
  }
}

module.exports = {
  pool,
  authenticateUser
};