const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session');
const passport = require('passport');
const GoogleStrategy = require('passport-google-oauth20').Strategy;
const { pool, authenticateUser } = require('./db');
const config = require('./config');

const app = express();
const port = 3000;

// Middleware
app.use(bodyParser.json());
app.use(express.static('.'));
app.use(session({
  secret: 'your-secret-key',
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false } // Set to true if using HTTPS
}));

// Initialize Passport and restore authentication state from session
app.use(passport.initialize());
app.use(passport.session());

// Passport configuration
passport.use(new GoogleStrategy({
  clientID: config.google.clientId,
  clientSecret: config.google.clientSecret,
  callbackURL: config.google.redirectUri
},
async function(accessToken, refreshToken, profile, done) {
  try {
    // Check if user exists in database
    const [rows] = await pool.promise().query('SELECT * FROM users WHERE google_id = ?', [profile.id]);
    
    if (rows.length > 0) {
      // User exists, return user
      return done(null, rows[0]);
    } else {
      // Create new user
      const [result] = await pool.promise().query(
        'INSERT INTO users (email, google_id, name) VALUES (?, ?, ?)',
        [profile.emails[0].value, profile.id, profile.displayName]
      );
      
      const newUser = {
        id: result.insertId,
        email: profile.emails[0].value,
        google_id: profile.id,
        name: profile.displayName
      };
      
      return done(null, newUser);
    }
  } catch (error) {
    return done(error, null);
  }
}));

passport.serializeUser((user, done) => {
  done(null, user.id);
});

passport.deserializeUser(async (id, done) => {
  try {
    const [rows] = await pool.promise().query('SELECT * FROM users WHERE id = ?', [id]);
    done(null, rows[0]);
  } catch (error) {
    done(error, null);
  }
});

// Login endpoint
app.post('/api/login', async (req, res) => {
  const { email, password } = req.body;

  try {
    const result = await authenticateUser(email, password);
    
    if (result.success) {
      req.session.user = result.user;
      res.json({ success: true });
    } else {
      res.json({ success: false, message: result.message });
    }
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ success: false, message: 'Internal server error' });
  }
});

// Check authentication status
app.get('/api/auth-status', (req, res) => {
  if (req.session.user) {
    res.json({ authenticated: true, user: req.session.user });
  } else {
    res.json({ authenticated: false });
  }
});

// Logout endpoint
app.post('/api/logout', (req, res) => {
  req.session.destroy();
  res.json({ success: true });
});

// Google OAuth routes
app.get('/api/auth/google',
  passport.authenticate('google', { scope: ['profile', 'email'] })
);

app.get('/api/auth/google/callback',
  passport.authenticate('google', { failureRedirect: '/login.html', failureMessage: true }),
  function(req, res) {
    // Successful authentication, redirect to vote page
    res.redirect('/vote.html');
  }
);

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Authentication error:', err);
  if (err.name === 'OAuth2Error') {
    res.redirect('/login.html?error=oauth');
  } else {
    res.redirect('/login.html?error=server');
  }
})
);

// Start server
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});