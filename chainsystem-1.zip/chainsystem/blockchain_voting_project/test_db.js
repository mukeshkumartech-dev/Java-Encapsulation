const { pool } = require('./db');

async function testDatabaseConnection() {
    try {
        // Test the connection
        const connection = await pool.promise().getConnection();
        console.log('Successfully connected to the database!');

        // Test if tables exist
        const [tables] = await connection.query(`
            SELECT table_name 
            FROM information_schema.tables 
            WHERE table_schema = 'voting_system'
        `);
        console.log('\nExisting tables in the database:');
        tables.forEach(table => console.log(`- ${table.table_name}`));

        // Test a simple query on users table
        const [userCount] = await connection.query('SELECT COUNT(*) as count FROM users');
        console.log(`\nNumber of users in the database: ${userCount[0].count}`);

        connection.release();
        console.log('\nDatabase connection test completed successfully!');
        process.exit(0);
    } catch (error) {
        console.error('Database connection test failed:', error);
        process.exit(1);
    }
}

testDatabaseConnection();