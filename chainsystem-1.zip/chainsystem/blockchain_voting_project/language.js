// Language translations
const translations = {
    'en': {
        // Common
        'welcome': 'WELCOME TO PAN INDIA VOTING SYSTEM',
        'home': 'Home',
        'details': 'Details',
        'login': 'Login',
        'signup': 'Sign-up',
        'clickMe': 'Click me',
        'cancel': 'Cancel',
        
        // Voting
        'enterAadhaar': 'Enter Your Aadhaar Number:',
        'vote': 'Vote',
        'verifyFingerprint': 'Please verify your fingerprint',
        'placeFinger': 'Place your finger on the sensor',
        
        // Guidelines
        'electionGuidelines': 'E-Voting Guidelines',
        'dos': 'Do\'s:',
        'donts': 'Don\'ts:',
        'ensureAuthentication': 'Ensure voter authentication: Use strong identity verification (like biometric or OTP) to confirm the voter\'s identity.',
        'useSecureSystems': 'Use secure and encrypted systems: Ensure end-to-end encryption to protect votes from tampering or hacking.',
        'maintainTransparency': 'Maintain transparency: The system must allow independent verification to ensure public trust.',
        'provideEducation': 'Provide voter education: Inform users how to cast their vote securely and correctly.',
        'auditRegularly': 'Audit and monitor regularly: Implement real-time monitoring and post-election audits to verify results.',
        'enableAccessibility': 'Enable accessibility: Make the platform user-friendly for people with disabilities, older voters, or those in rural areas.',
        'backupVotes': 'Back up votes securely: Have a system for securely backing up and recovering vote data if needed.',
        'dontIgnoreSecurity': 'Don\'t ignore cybersecurity threats: Never overlook potential attacks like DDoS, phishing, or malware.',
        'dontAllowMultipleVotes': 'Don\'t allow multiple votes: A single voter should never be able to vote more than once.',
        'dontBypassTesting': 'Don\'t bypass testing: Always test the system thoroughly before deployment.',
        'dontMakeComplex': 'Don\'t make the system overly complex: A complicated system can confuse voters and reduce trust.',
        'dontCompromisePrivacy': 'Don\'t compromise voter privacy: Never store information that links a voter to their vote.',
        'dontLaunchWithoutPlan': 'Don\'t launch without contingency planning: Always prepare for system failures or emergencies.',
        'benefits': 'Benefits of E-Voting Systems',
        'benefitsDescription': 'E-voting systems offer a modern, efficient, and accessible way to conduct elections, enhancing both speed and convenience. One of the major advantages is that it significantly reduces the time and cost of manual vote counting, offering instant results. E-voting can also increase voter turnout by making the process more accessible for people who live far from polling stations or have mobility issues. Moreover, digital systems help minimize human errors and allow for better tracking and auditing of votes. With proper encryption and cybersecurity measures, e-voting can be a secure and transparent alternative to traditional voting methods, enabling a more inclusive and tech-forward democratic process.',
        'copyright': '© 2024 Government E-Voting Portal. All rights reserved.'
    },
    'hi': {
        // Common
        'welcome': 'पैन इंडिया वोटिंग सिस्टम में आपका स्वागत है',
        'home': 'होम',
        'details': 'विवरण',
        'login': 'लॉगिन',
        'signup': 'साइन अप',
        'clickMe': 'क्लिक करें',
        'cancel': 'रद्द करें',
        
        // Voting
        'enterAadhaar': 'अपना आधार नंबर दर्ज करें:',
        'vote': 'वोट करें',
        'verifyFingerprint': 'कृपया अपनी फिंगरप्रिंट सत्यापित करें',
        'placeFinger': 'सेंसर पर अपनी उंगली रखें',
        
        // Guidelines
        'electionGuidelines': 'ई-वोटिंग दिशा-निर्देश',
        'dos': 'क्या करें:',
        'donts': 'क्या न करें:',
        'ensureAuthentication': 'मतदाता प्रमाणीकरण सुनिश्चित करें: मतदाता की पहचान की पुष्टि के लिए मजबूत पहचान सत्यापन (जैसे बायोमेट्रिक या ओटीपी) का उपयोग करें।',
        'useSecureSystems': 'सुरक्षित और एन्क्रिप्टेड सिस्टम का उपयोग करें: वोटों को छेड़छाड़ या हैकिंग से बचाने के लिए एंड-टू-एंड एन्क्रिप्शन सुनिश्चित करें।',
        'maintainTransparency': 'पारदर्शिता बनाए रखें: सिस्टम को सार्वजनिक विश्वास सुनिश्चित करने के लिए स्वतंत्र सत्यापन की अनुमति देनी चाहिए।',
        'provideEducation': 'मतदाता शिक्षा प्रदान करें: उपयोगकर्ताओं को सुरक्षित और सही तरीके से वोट डालने का तरीका बताएं।',
        'auditRegularly': 'नियमित रूप से ऑडिट और मॉनिटर करें: परिणामों की पुष्टि के लिए रीयल-टाइम मॉनिटरिंग और चुनाव के बाद के ऑडिट लागू करें।',
        'enableAccessibility': 'सुलभता सक्षम करें: विकलांग लोगों, वरिष्ठ मतदाताओं या ग्रामीण क्षेत्रों के लोगों के लिए प्लेटफॉर्म को उपयोगकर्ता के अनुकूल बनाएं।',
        'backupVotes': 'वोटों का सुरक्षित बैकअप लें: यदि आवश्यक हो तो वोट डेटा को सुरक्षित रूप से बैकअप और रिकवर करने के लिए एक सिस्टम रखें।',
        'dontIgnoreSecurity': 'साइबर सुरक्षा खतरों को नजरअंदाज न करें: डीडीओएस, फिशिंग या मैलवेयर जैसे संभावित हमलों को कभी नजरअंदाज न करें।',
        'dontAllowMultipleVotes': 'एकाधिक वोटों की अनुमति न दें: एक मतदाता को कभी भी एक से अधिक बार वोट नहीं देना चाहिए।',
        'dontBypassTesting': 'टेस्टिंग को बायपास न करें: डिप्लॉयमेंट से पहले हमेशा सिस्टम की पूरी तरह से टेस्टिंग करें।',
        'dontMakeComplex': 'सिस्टम को अत्यधिक जटिल न बनाएं: एक जटिल सिस्टम मतदाताओं को भ्रमित कर सकता है और विश्वास कम कर सकता है।',
        'dontCompromisePrivacy': 'मतदाता की गोपनीयता से समझौता न करें: कभी भी ऐसी जानकारी स्टोर न करें जो मतदाता को उनके वोट से जोड़ती हो।',
        'dontLaunchWithoutPlan': 'आकस्मिक योजना के बिना लॉन्च न करें: सिस्टम विफलताओं या आपात स्थितियों के लिए हमेशा तैयार रहें।',
        'benefits': 'ई-वोटिंग सिस्टम के लाभ',
        'benefitsDescription': 'ई-वोटिंग सिस्टम चुनाव आयोजित करने का एक आधुनिक, कुशल और सुलभ तरीका प्रदान करता है, जो गति और सुविधा दोनों को बढ़ाता है। प्रमुख लाभों में से एक यह है कि यह मैनुअल वोट गिनती के समय और लागत को काफी कम कर देता है, तुरंत परिणाम प्रदान करता है। ई-वोटिंग मतदान केंद्रों से दूर रहने वाले या गतिशीलता संबंधी समस्याओं वाले लोगों के लिए प्रक्रिया को अधिक सुलभ बनाकर मतदान में भागीदारी भी बढ़ा सकता है। इसके अलावा, डिजिटल सिस्टम मानवीय त्रुटियों को कम करने में मदद करते हैं और वोटों के बेहतर ट्रैकिंग और ऑडिटिंग की अनुमति देते हैं। उचित एन्क्रिप्शन और साइबर सुरक्षा उपायों के साथ, ई-वोटिंग पारंपरिक मतदान विधियों का एक सुरक्षित और पारदर्शी विकल्प हो सकता है, जो अधिक समावेशी और तकनीक-आगे लोकतांत्रिक प्रक्रिया को सक्षम बनाता है।',
        'copyright': '© 2024 सरकारी ई-वोटिंग पोर्टल। सर्वाधिकार सुरक्षित।'
    },
    'ta': {
        // Common
        'welcome': 'பான் இந்திய வாக்களிப்பு அமைப்புக்கு வரவேற்கிறோம்',
        'home': 'முகப்பு',
        'details': 'விவரங்கள்',
        'login': 'உள்நுழை',
        'signup': 'பதிவு செய்க',
        'clickMe': 'கிளிக் செய்யவும்',
        'cancel': 'ரத்து செய்',
        
        // Voting
        'enterAadhaar': 'உங்கள் ஆதார் எண்ணை உள்ளிடவும்:',
        'vote': 'வாக்களிக்கவும்',
        'verifyFingerprint': 'உங்கள் கைரேகையை சரிபார்க்கவும்',
        'placeFinger': 'சென்சரில் உங்கள் விரலை வைக்கவும்',
        
        // Guidelines
        'electionGuidelines': 'மின்-வாக்களிப்பு வழிகாட்டுதல்கள்',
        'dos': 'செய்ய வேண்டியவை:',
        'donts': 'செய்யக்கூடாதவை:',
        'ensureAuthentication': 'வாக்காளர் அங்கீகாரத்தை உறுதிப்படுத்தவும்: வாக்காளரின் அடையாளத்தை உறுதிப்படுத்த உறுதியான அடையாள சரிபார்ப்பு (உயிரியளவியல் அல்லது OTP போன்றவை) பயன்படுத்தவும்.',
        'useSecureSystems': 'பாதுகாப்பான மற்றும் குறியாக்கப்பட்ட அமைப்புகளைப் பயன்படுத்தவும்: வாக்குகளை கையாளுதல் அல்லது ஹேக்கிங் இருந்து பாதுகாக்க முழு-முனை குறியாக்கத்தை உறுதிப்படுத்தவும்.',
        'maintainTransparency': 'வெளிப்படைத்தன்மையை பராமரிக்கவும்: பொது நம்பிக்கையை உறுதிப்படுத்த சுயாதீன சரிபார்ப்பை அனுமதிக்கும் அமைப்பு இருக்க வேண்டும்.',
        'provideEducation': 'வாக்காளர் கல்வியை வழங்கவும்: பாதுகாப்பாகவும் சரியாகவும் வாக்களிக்க பயனர்களுக்கு எப்படி என்று தெரிவிக்கவும்.',
        'auditRegularly': 'தொடர்ந்து ஆடிட் மற்றும் கண்காணிக்கவும்: முடிவுகளை சரிபார்க்க உண்மையான நேர கண்காணிப்பு மற்றும் தேர்தல் பின் ஆடிட் செயல்படுத்தவும்.',
        'enableAccessibility': 'அணுகல்தன்மையை இயக்கவும்: மாற்றுத்திறனாளிகள், முதிய வாக்காளர்கள் அல்லது கிராமப்புறங்களில் உள்ளவர்களுக்கு தளத்தை பயனர் நட்பு ஆக்கவும்.',
        'backupVotes': 'வாக்குகளை பாதுகாப்பாக காப்பு வைக்கவும்: தேவைப்பட்டால் வாக்கு தரவை பாதுகாப்பாக காப்பு வைத்து மீட்டெடுக்க ஒரு அமைப்பு இருக்க வேண்டும்.',
        'dontIgnoreSecurity': 'சைபர் பாதுகாப்பு அச்சுறுத்தல்களை புறக்கணிக்காதீர்கள்: DDoS, ஃபிஷிங் அல்லது மால்வேர் போன்ற சாத்தியமான தாக்குதல்களை ஒருபோதும் புறக்கணிக்காதீர்கள்.',
        'dontAllowMultipleVotes': 'பல வாக்குகளை அனுமதிக்காதீர்கள்: ஒரு வாக்காளர் ஒரு முறைக்கு மேல் வாக்களிக்கக்கூடாது.',
        'dontBypassTesting': 'சோதனையை தவிர்க்காதீர்கள்: பயன்படுத்துவதற்கு முன் எப்போதும் அமைப்பை முழுமையாக சோதிக்கவும்.',
        'dontMakeComplex': 'அமைப்பை மிகவும் சிக்கலாக ஆக்காதீர்கள்: சிக்கலான அமைப்பு வாக்காளர்களை குழப்பலாம் மற்றும் நம்பிக்கையை குறைக்கலாம்.',
        'dontCompromisePrivacy': 'வாக்காளர் தனியுரிமையை சமரசம் செய்யாதீர்கள்: வாக்காளரை அவரது வாக்குடன் இணைக்கும் தகவலை ஒருபோதும் சேமிக்காதீர்கள்.',
        'dontLaunchWithoutPlan': 'ஒப்பந்த திட்டம் இல்லாமல் தொடங்காதீர்கள்: அமைப்பு தோல்விகள் அல்லது அவசரகாலங்களுக்கு எப்போதும் தயாராக இருங்கள்.',
        'benefits': 'மின்-வாக்களிப்பு அமைப்புகளின் நன்மைகள்',
        'benefitsDescription': 'மின்-வாக்களிப்பு அமைப்புகள் தேர்தல்களை நடத்துவதற்கான ஒரு நவீன, திறமையான மற்றும் அணுகக்கூடிய வழியை வழங்குகின்றன, இது வேகம் மற்றும் வசதி இரண்டையும் மேம்படுத்துகிறது. முக்கிய நன்மைகளில் ஒன்று, இது கைமுறை வாக்கு எண்ணிக்கையின் நேரம் மற்றும் செலவை கணிசமாக குறைக்கிறது, உடனடி முடிவுகளை வழங்குகிறது. மின்-வாக்களிப்பு வாக்குச்சாவடிகளிலிருந்து தொலைவில் வாழ்பவர்கள் அல்லது இயக்கத்திறன் பிரச்சினைகள் உள்ளவர்களுக்கு செயல்முறையை மிகவும் அணுகக்கூடியதாக ஆக்கி வாக்களிப்பு விகிதத்தையும் அதிகரிக்க முடியும். மேலும், டிஜிட்டல் அமைப்புகள் மனித பிழைகளை குறைக்க உதவுகின்றன மற்றும் வாக்குகளின் சிறந்த கண்காணிப்பு மற்றும் ஆடிட் செய்ய அனுமதிக்கின்றன. சரியான குறியாக்கம் மற்றும் சைபர் பாதுகாப்பு நடவடிக்கைகளுடன், மின்-வாக்களிப்பு பாரம்பரிய வாக்களிப்பு முறைகளுக்கு பாதுகாப்பான மற்றும் வெளிப்படையான மாற்றாக இருக்க முடியும், இது மிகவும் உள்ளடக்கிய மற்றும் தொழில்நுட்ப-முன்னோடி ஜனநாயக செயல்முறையை செயல்படுத்துகிறது.',
        'copyright': '© 2024 அரசு மின்-வாக்களிப்பு போர்டல். அனைத்து உரிமைகளும் பாதுகாக்கப்பட்டவை.'
    }
};

// Function to change language
function changeLanguage(lang) {
    const elements = document.querySelectorAll('[data-translate]');
    elements.forEach(element => {
        const key = element.getAttribute('data-translate');
        if (translations[lang] && translations[lang][key]) {
            element.textContent = translations[lang][key];
        }
    });
    
    // Update select options
    const select = document.getElementById('languageSelect');
    if (select) {
        select.value = lang;
    }
    
    // Announce language change
    announceLanguage(lang);
}

// Function to speak text
function speakText(text, lang) {
    const synth = window.speechSynthesis;
    const utterance = new SpeechSynthesisUtterance(text);
    
    // Set language
    utterance.lang = lang;
    
    // Find appropriate voice
    const voices = synth.getVoices();
    const voice = voices.find(v => v.lang === lang) || voices[0];
    if (voice) {
        utterance.voice = voice;
    }
    
    // Configure speech
    utterance.rate = 0.9;
    utterance.pitch = 1;
    utterance.volume = 1;
    
    // Speak
    synth.cancel(); // Cancel any ongoing speech
    synth.speak(utterance);
}

// Function to announce language change
function announceLanguage(lang) {
    const announcements = {
        'en': 'Language changed to English',
        'hi': 'भाषा हिंदी में बदल गई है',
        'ta': 'மொழி தமிழுக்கு மாற்றப்பட்டது'
    };
    
    if (announcements[lang]) {
        speakText(announcements[lang], lang);
    }
}

// Function to speak content
function speakContent() {
    const currentLang = document.getElementById('languageSelect').value;
    const elements = document.querySelectorAll('[data-translate]');
    let textToSpeak = '';
    
    elements.forEach(element => {
        const key = element.getAttribute('data-translate');
        if (translations[currentLang] && translations[currentLang][key]) {
            textToSpeak += translations[currentLang][key] + '. ';
        }
    });
    
    speakText(textToSpeak, currentLang);
}

// Initialize voices when the page loads
if (speechSynthesis.onvoiceschanged !== undefined) {
    speechSynthesis.onvoiceschanged = () => {
        speechSynthesis.getVoices();
    };
}

// Add event listener for language change
document.addEventListener('DOMContentLoaded', () => {
    const languageSelect = document.getElementById('languageSelect');
    if (languageSelect) {
        languageSelect.addEventListener('change', (e) => {
            changeLanguage(e.target.value);
        });
    }
});