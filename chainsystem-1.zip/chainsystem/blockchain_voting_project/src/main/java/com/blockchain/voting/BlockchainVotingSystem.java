 package com.blockchain.voting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.*;

@SpringBootApplication
@RestController
@CrossOrigin(origins = "*")
public class BlockchainVotingSystem {

    private final Blockchain blockchain;

    public BlockchainVotingSystem() {
        this.blockchain = new Blockchain();
    }


    public static void main(String[] args) {
        SpringApplication.run(BlockchainVotingSystem.class, args);
    }

    @Bean
    public WebMvcConfigurer corsConfigurer() {
        return new WebMvcConfigurer() {
            @Override
            public void addCorsMappings(CorsRegistry registry) {
                registry.addMapping("/**")
                    .allowedOrigins("*")
                    .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
                    .allowedHeaders("*");
            }
        };
    }

    // REST API Endpoints
    @PostMapping("/vote")
    public ResponseEntity<Map<String, String>> castVote(@RequestBody VoteRequest request) {
        if (!isValidAadhar(request.getAadharNumber())) {
            return ResponseEntity.badRequest()
                .body(Map.of("message", "Invalid Aadhar number format"));
        }

        if (blockchain.hasVoted(request.getAadharNumber())) {
            return ResponseEntity.badRequest()
                .body(Map.of("message", "You have already voted!"));
        }

        boolean success = blockchain.addVote(request.getAadharNumber(), request.getVote());
        
        if (success) {
            return ResponseEntity.ok()
                .body(Map.of("message", "Vote cast successfully!"));
        } else {
            return ResponseEntity.internalServerError()
                .body(Map.of("message", "Error processing vote"));
        }
    }

    @GetMapping("/results")
    public ResponseEntity<Map<String, Integer>> getResults() {
        if (!blockchain.isChainValid()) {
            return ResponseEntity.internalServerError()
                .body(Map.of());
        }
        return ResponseEntity.ok(blockchain.getVoteCounts());
    }

    @GetMapping("/verify/{aadharNumber}")
    public ResponseEntity<Map<String, Boolean>> verifyVoter(@PathVariable String aadharNumber) {
        if (!isValidAadhar(aadharNumber)) {
            return ResponseEntity.badRequest()
                .body(Map.of("hasVoted", false));
        }
        return ResponseEntity.ok()
            .body(Map.of("hasVoted", blockchain.hasVoted(aadharNumber)));
    }

    private boolean isValidAadhar(String aadharNumber) {
        String cleaned = aadharNumber.replaceAll("\\s+", "");
        return cleaned.matches("\\d{12}");
    }
}

// Block class for blockchain
class Block {
    private String hash;
    private String previousHash;
    private VoteData data;
    private long timeStamp;
    private int nonce;

    public Block(VoteData data, String previousHash) {
        this.data = data;
        this.previousHash = previousHash;
        this.timeStamp = new Date().getTime();
        this.hash = calculateHash();
    }

    public String calculateHash() {
        String dataToHash = previousHash 
            + Long.toString(timeStamp) 
            + Integer.toString(nonce) 
            + data.toString();
        
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] bytes = digest.digest(dataToHash.getBytes());
            StringBuilder builder = new StringBuilder();
            for (byte b : bytes) {
                builder.append(String.format("%02x", b));
            }
            return builder.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }

    public void mineBlock(int difficulty) {
        String target = new String(new char[difficulty]).replace('\0', '0');
        while (!hash.substring(0, difficulty).equals(target)) {
            nonce++;
            hash = calculateHash();
        }
        System.out.println("Block Mined: " + hash);
    }

    // Getters
    public String getHash() { return hash; }
    public String getPreviousHash() { return previousHash; }
    public VoteData getData() { return data; }
    public long getTimeStamp() { return timeStamp; }
}

// VoteData class to store vote information
class VoteData {
    private final String voterId;
    private final String candidateId;
    private final long timestamp;
    private final String encryptedVoteHash;

    public VoteData(String aadharNumber, String candidateId) {
        this.voterId = encryptAadhar(aadharNumber);
        this.candidateId = candidateId;
        this.timestamp = new Date().getTime();
        this.encryptedVoteHash = calculateVoteHash();
    }

    private String encryptAadhar(String aadharNumber) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(aadharNumber.getBytes());
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }

    private String calculateVoteHash() {
        try {
            String dataToHash = voterId + candidateId + timestamp;
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(dataToHash.getBytes());
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }

    // Getters
    public String getVoterId() { return voterId; }
    public String getCandidateId() { return candidateId; }
    public long getTimestamp() { return timestamp; }
    public String getEncryptedVoteHash() { return encryptedVoteHash; }

    @Override
    public String toString() {
        return voterId + candidateId + timestamp + encryptedVoteHash;
    }
}

// Blockchain class to manage the chain
class Blockchain {
    private List<Block> chain;
    private Map<String, Boolean> usedVoterIds;
    private int difficulty;

    public Blockchain() {
        chain = new ArrayList<>();
        usedVoterIds = new HashMap<>();
        difficulty = 4;
        createGenesisBlock();
    }

    private void createGenesisBlock() {
        VoteData genesisData = new VoteData("0000000000000000", "GENESIS");
        chain.add(new Block(genesisData, "0"));
    }

    public Block getLatestBlock() {
        return chain.get(chain.size() - 1);
    }

    public synchronized boolean addVote(String aadharNumber, String candidateId) {
        VoteData voteData = new VoteData(aadharNumber, candidateId);
        
        if (usedVoterIds.containsKey(voteData.getVoterId())) {
            return false;
        }

        Block newBlock = new Block(voteData, getLatestBlock().getHash());
        newBlock.mineBlock(difficulty);
        
        chain.add(newBlock);
        usedVoterIds.put(voteData.getVoterId(), true);
        
        return true;
    }

    public boolean isChainValid() {
        for (int i = 1; i < chain.size(); i++) {
            Block currentBlock = chain.get(i);
            Block previousBlock = chain.get(i - 1);

            if (!currentBlock.getHash().equals(currentBlock.calculateHash())) {
                return false;
            }

            if (!currentBlock.getPreviousHash().equals(previousBlock.getHash())) {
                return false;
            }
        }
        return true;
    }

    public Map<String, Integer> getVoteCounts() {
        Map<String, Integer> voteCounts = new HashMap<>();
        
        for (int i = 1; i < chain.size(); i++) {
            String candidateId = chain.get(i).getData().getCandidateId();
            voteCounts.put(candidateId, voteCounts.getOrDefault(candidateId, 0) + 1);
        }
        
        return voteCounts;
    }

    public boolean hasVoted(String aadharNumber) {
        VoteData tempVoteData = new VoteData(aadharNumber, "CHECK");
        return usedVoterIds.containsKey(tempVoteData.getVoterId());
    }

    public List<Block> getChain() {
        return new ArrayList<>(chain);
    }

    public int getChainSize() {
        return chain.size();
    }
}

// Request class for vote submission
class VoteRequest {
    private String aadharNumber;
    private String vote;

    public String getAadharNumber() { return aadharNumber; }
    public void setAadharNumber(String aadharNumber) { this.aadharNumber = aadharNumber; }
    public String getVote() { return vote; }
    public void setVote(String vote) { this.vote = vote; }
}