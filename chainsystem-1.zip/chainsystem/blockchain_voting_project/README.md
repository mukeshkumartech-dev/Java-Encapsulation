# Blockchain Voting System

A secure and transparent voting system built using blockchain technology.

## Project Structure

```
blockchain_voting_project/
├── backend/
│   ├── app.py           # Flask backend with blockchain implementation
│   ├── requirements.txt # Python dependencies
│   └── chain.json      # Blockchain data storage
└── vote.html           # Frontend voting interface
```

## Setup Instructions

1. Install Python 3.7 or higher
2. Navigate to the backend directory:
   ```bash
   cd backend
   ```
3. Create a virtual environment (optional but recommended):
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```
4. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

## Running the Application

1. Start the backend server:
   ```bash
   python app.py
   ```
   The server will start on http://localhost:5000

2. Open `vote.html` in your web browser to access the voting interface

## Features

- Secure voting using Aadhaar number verification
- One vote per voter
- Transparent vote counting
- Immutable vote records using blockchain
- Real-time vote verification

## API Endpoints

- `POST /vote` - Cast a vote
- `GET /results` - Get current voting results
- `GET /verify/<aadhar_number>` - Check if a voter has already voted
- `GET /chain` - Get the entire blockchain

## Security Features

- SHA-256 hashing for block integrity
- Proof of Work (PoW) for block validation
- Unique voter identification
- Immutable vote records 