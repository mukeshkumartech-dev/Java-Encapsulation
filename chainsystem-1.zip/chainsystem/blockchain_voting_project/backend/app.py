import hashlib
import json
from flask import Flask, request, jsonify, redirect
from flask_cors import CORS
from datetime import datetime

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Development configuration
app.config['DEBUG'] = True
app.config['ENV'] = 'development'

# Blockchain class
class Blockchain:
    def __init__(self):
        self.chain = []
        self.votes = set()  # To keep track of Aadhaar numbers
        self.fingerprint_verified = set()  # To track fingerprint verification

    def create_block(self, aadhaar_number, vote, fingerprint_verified):
        if not fingerprint_verified:
            raise ValueError("Fingerprint verification required")
            
        block = {
            'index': len(self.chain) + 1,
            'aadhaar_number': aadhaar_number,
            'vote': vote,
            'fingerprint_verified': fingerprint_verified,
            'timestamp': str(datetime.now()),
            'previous_hash': self.hash(self.chain[-1]) if self.chain else '0'
        }
        self.chain.append(block)
        self.votes.add(aadhaar_number)
        self.fingerprint_verified.add(aadhaar_number)
        return block

    def hash(self, block):
        encoded_block = json.dumps(block, sort_keys=True).encode()
        return hashlib.sha256(encoded_block).hexdigest()

    def has_voted(self, aadhaar_number):
        return aadhaar_number in self.votes

    def is_fingerprint_verified(self, aadhaar_number):
        return aadhaar_number in self.fingerprint_verified

# Initialize blockchain
blockchain = Blockchain()

@app.route('/vote', methods=['POST'])
def vote():
    data = request.get_json()
    aadhaar_number = data.get('aadhaar_number')
    vote = data.get('vote')
    fingerprint_verified = data.get('fingerprint_verified', False)

    if not aadhaar_number or not vote:
        return jsonify({'message': 'Aadhaar number and vote are required'}), 400

    if blockchain.has_voted(aadhaar_number):
        return jsonify({'message': 'You have already voted!'}), 403

    if not fingerprint_verified:
        return jsonify({'message': 'Fingerprint verification required'}), 401

    try:
        blockchain.create_block(aadhaar_number, vote, fingerprint_verified)
        return jsonify({'message': 'Vote cast successfully!'}), 200
    except ValueError as e:
        return jsonify({'message': str(e)}), 400

@app.route('/exit', methods=['GET'])
def exit_page():
    return redirect("about:blank", code=302)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)